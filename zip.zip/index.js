(() => {
//let key = "&units=metric&APPID=a7e2d9ef998da83a537f356def67d0ec";
    let input = document.getElementById("input");
    let country = document.getElementById('country-code');
// let url = "https://api.openweathermap.org/data/2.5/forecast?q=";
    document.getElementById("run").addEventListener("click", function () {
        fetch("https://api.openweathermap.org/data/2.5/forecast?q=" + input.value + "," + country.value + "&units=metric&APPID=a7e2d9ef998da83a537f356def67d0ec")
            .then(function (response) {
                return response.json();
            }).then(function (data) {
                console.log(data);

                let temp = data.list[0].main.temp; //e cogido del data lo que necesitava y si miramos en la consola veremos porque en ese metodo

                document.getElementsByClassName("card-title city1")[0].innerHTML = input.value;
                document.getElementsByClassName("card-title city2")[0].innerHTML = input.value;
                document.getElementsByClassName("card-title city3")[0].innerHTML = input.value;
                document.getElementsByClassName("card-title city4")[0].innerHTML = input.value;
                document.getElementsByClassName("card-title city5")[0].innerHTML = input.value;



                document.getElementsByClassName("card-text")[0].innerHTML = temp + "°" ;
                document.getElementsByClassName("card-text")[1].innerHTML = temp + "°";
                document.getElementsByClassName("card-text")[2].innerHTML = temp + "°";
                document.getElementsByClassName("card-text")[3].innerHTML = temp + "°";
                document.getElementsByClassName("card-text")[4].innerHTML = temp + "°";

                let description = data.list[0].weather[0].description;

                document.getElementsByClassName("description")[0].innerHTML = description ;

                let icon = data.list[0].weather[0].icon;
                let img1 = document.getElementById("pic1");
                img1.src = "http://openweathermap.org/img/wn/"+ icon +".png";

                console.log(img1);
                //document.getElementsByClassName("icon")[0].innerHTML = icon ;





            })



    });
})();
